extends RefCounted

const WORLD_NAMES = [
    "الأشكال الأساسية",
    "الهندسة المتقدمة",
    "الرموز والإشارات",
    "الأدوات المكتبية",
    "أشياء المنزل",
    "عالم المطبخ",
    "الألعاب",
    "الموسيقى",
    "الرياضة",
    "الورشة والأدوات",
    "السيارات",
    "الشاحنات",
    "الحافلات والعربات",
    "المعدات الثقيلة",
    "الطيران",
    "البحر والمراكب",
    "القطارات",
    "الدراجات",
    "الآلات المتحركة",
    "المرور والمدينة",
    "الحيوانات الأليفة",
    "حيوانات المزرعة",
    "حيوانات الغابة",
    "حيوانات الصحراء",
    "الطيور",
    "الحياة البحرية",
    "الحشرات",
    "الزواحف",
    "الديناصورات",
    "الحياة البرية",
    "الفواكه",
    "الخضروات",
    "الحلويات",
    "المشروبات",
    "الوجبات",
    "الزهور",
    "الأشجار",
    "النباتات",
    "الحدائق",
    "الطبيعة والطعام",
    "البيوت",
    "الأبراج",
    "القلاع",
    "الجسور",
    "المدينة الكبيرة",
    "المصانع",
    "التقنية والروبوت",
    "الفضاء",
    "الخيال والأساطير",
    "العالم الختامي"
]

const ADVANCED_TIER_NAMES = [
    "المتقدم",
    "المتشابك",
    "الكثيف",
    "المعقد",
    "الخبير",
    "النخبة",
    "الفائق",
    "الأسطوري",
    "المتاهة الكبرى",
    "التحدي النهائي"
]

const WORLD_POOLS = [
    ["circle","triangle","rect","diamond","hex","star"],
    ["star","hex","oct","rings","flower","spiral","maze"],
    ["heart","shield","crown","bolt","key","star"],
    ["book","pencil","scissors","folder","key"],
    ["cup","chair","lamp","clock","key"],
    ["cup","bottle","pan","spoon","fork"],
    ["balloon","kite","robot","car","ball"],
    ["guitar","note","drum","star","ball"],
    ["ball","trophy","shield","star","shoe"],
    ["wrench","hammer","gear","key","bolt"],
    ["car","sportcar","pickup","van"],
    ["truck","tanker","pickup","van"],
    ["bus","van","car","truck"],
    ["bulldozer","crane","truck","gear"],
    ["plane","helicopter","balloon","rocket"],
    ["boat","ship","submarine","fish"],
    ["train","metro","tram","gear"],
    ["bike","motorcycle","scooter","helmet"],
    ["gear","robot","crane","wrench","conveyor"],
    ["car","bus","truck","traffic_sign","house"],
    ["cat","dog","rabbit","bird"],
    ["horse","cow","sheep","chicken"],
    ["lion","elephant","monkey","bear"],
    ["camel","fox","snake","scorpion"],
    ["bird","owl","eagle","peacock"],
    ["fish","dolphin","turtle","octopus"],
    ["butterfly","bee","beetle","dragonfly"],
    ["crocodile","snake","turtle","lizard"],
    ["dinosaur","trex","pterosaur","egg"],
    ["giraffe","elephant","lion","horse","bird"],
    ["apple","banana","pear","grapes"],
    ["carrot","pepper","eggplant","corn"],
    ["cake","icecream","donut","candy"],
    ["cup","bottle","teapot","glass"],
    ["pizza","burger","sandwich","fries"],
    ["flower","rose","tulip","sunflower"],
    ["tree","palm","pine","leaf"],
    ["cactus","leaf","flower","pot"],
    ["tree","flower","butterfly","bench"],
    ["apple","leaf","flower","tree","cup"],
    ["house","villa","key","door"],
    ["tower","lighthouse","skyscraper"],
    ["castle","tower","shield","crown"],
    ["bridge","boat","car"],
    ["house","tower","car","bus"],
    ["factory","gear","truck","crane"],
    ["phone","laptop","robot","gear"],
    ["rocket","planet","moon","star","alien"],
    ["dragon","crown","castle","shield","star"],
    ["star","rocket","dragon","car","elephant","castle","gear","heart"]
]

static func _base_world_index(world_number):
    if world_number <= 50:
        return clamp(int(world_number) - 1, 0, 49)
    return int((world_number - 51) % 50)

static func _advanced_tier_index(world_number):
    if world_number <= 50:
        return 0
    return clamp(int(floor(float(world_number - 51) / 50.0)), 0, ADVANCED_TIER_NAMES.size() - 1)

static func world_name(world_number):
    var base_index = _base_world_index(world_number)
    if world_number <= 50:
        return WORLD_NAMES[base_index]
    return "%s • %s" % [WORLD_NAMES[base_index], ADVANCED_TIER_NAMES[_advanced_tier_index(world_number)]]

static func shape_pool(world_number):
    var base_index = _base_world_index(world_number)
    var pool = WORLD_POOLS[base_index].duplicate()
    if world_number > 50:
        var tier = _advanced_tier_index(world_number)
        var neighbor_index = (base_index + 7 + tier * 5) % WORLD_POOLS.size()
        var neighbor = WORLD_POOLS[neighbor_index]
        for i in range(min(2, neighbor.size())):
            var candidate = neighbor[(i + tier) % neighbor.size()]
            if not pool.has(candidate):
                pool.append(candidate)
    return pool

static func layout_mode(world_number):
    if world_number <= 50:
        return "cluster"
    var advanced_world = world_number - 51
    var selector = advanced_world % 7
    if selector in [0, 1, 2]:
        return "solo"
    if selector in [3, 4]:
        return "duo"
    return "cluster"

static func formation_count(local_level, world_number):
    if world_number <= 50:
        if world_number <= 1:
            return clamp(2 + int(floor(float(local_level - 1) / 4.0)), 2, 7)
        var base = 5
        if world_number >= 11:
            base = 6
        if world_number >= 31:
            base = 7
        var count = base + int(floor(float(local_level - 1) / 7.0))
        return clamp(count, 5, 8)
    var mode = layout_mode(world_number)
    if mode == "solo":
        return 1
    if mode == "duo":
        return 2
    return 3 + int(floor(float(local_level - 1) / 8.0))

static func featured_shapes(world_number, count):
    var pool = shape_pool(world_number)
    var result = []
    if pool.is_empty():
        return ["circle"]
    var seed_index = abs(world_number * 17 + _advanced_tier_index(world_number) * 11) % pool.size()
    for i in range(count):
        var kind = pool[(seed_index + i * 3) % pool.size()]
        if result.has(kind) and pool.size() > result.size():
            kind = pool[(seed_index + i * 3 + 1) % pool.size()]
        result.append(kind)
    return result

static func palette(world_number):
    var base_world = _base_world_index(world_number) + 1
    if base_world <= 10:
        return {
            "bg": Color(0.945, 0.965, 1.0, 1.0),
            "decor": [Color(0.20,0.64,1.0,0.20), Color(0.80,0.32,0.95,0.18), Color(0.22,0.82,0.52,0.18), Color(1.0,0.58,0.20,0.18), Color(1.0,0.30,0.55,0.17)]
        }
    if base_world <= 20:
        return {
            "bg": Color(0.94, 0.965, 0.985, 1.0),
            "decor": [Color(0.12,0.55,0.90,0.19), Color(0.98,0.55,0.15,0.19), Color(0.85,0.20,0.18,0.16), Color(0.25,0.32,0.42,0.14), Color(0.10,0.75,0.78,0.16)]
        }
    if base_world <= 30:
        return {
            "bg": Color(0.95, 0.985, 0.95, 1.0),
            "decor": [Color(0.20,0.72,0.32,0.18), Color(0.95,0.70,0.18,0.18), Color(0.55,0.35,0.16,0.14), Color(0.20,0.62,0.88,0.16), Color(0.90,0.42,0.35,0.16)]
        }
    if base_world <= 40:
        return {
            "bg": Color(1.0, 0.965, 0.955, 1.0),
            "decor": [Color(1.0,0.42,0.50,0.18), Color(1.0,0.68,0.18,0.18), Color(0.38,0.78,0.42,0.17), Color(0.72,0.36,0.92,0.16), Color(0.15,0.65,0.82,0.16)]
        }
    if base_world <= 46:
        return {
            "bg": Color(0.95, 0.965, 0.985, 1.0),
            "decor": [Color(0.20,0.48,0.78,0.17), Color(0.48,0.55,0.65,0.15), Color(0.92,0.66,0.18,0.16), Color(0.18,0.70,0.68,0.16), Color(0.72,0.32,0.35,0.14)]
        }
    if base_world == 47:
        return {
            "bg": Color(0.94, 0.965, 1.0, 1.0),
            "decor": [Color(0.10,0.74,0.92,0.19), Color(0.50,0.30,0.95,0.18), Color(0.15,0.88,0.62,0.16), Color(0.20,0.36,0.76,0.15)]
        }
    if base_world == 48:
        return {
            "bg": Color(0.925, 0.94, 0.995, 1.0),
            "decor": [Color(0.30,0.32,0.95,0.18), Color(0.68,0.28,0.94,0.18), Color(0.18,0.65,0.95,0.18), Color(0.98,0.76,0.20,0.18)]
        }
    if base_world == 49:
        return {
            "bg": Color(0.985, 0.945, 0.995, 1.0),
            "decor": [Color(0.75,0.28,0.90,0.18), Color(0.98,0.62,0.16,0.18), Color(0.95,0.30,0.55,0.17), Color(0.28,0.58,0.95,0.16)]
        }
    return {
        "bg": Color(0.965, 0.955, 0.995, 1.0),
        "decor": [Color(0.95,0.25,0.35,0.18), Color(1.0,0.65,0.12,0.18), Color(0.20,0.72,0.38,0.18), Color(0.18,0.60,0.95,0.18), Color(0.66,0.30,0.92,0.18)]
    }
