extends Node2D

signal escape_finished(route)

var route_points = PackedVector2Array()
var cumulative = PackedFloat32Array()
var total_length = 0.0
var exit_dir = Vector2.RIGHT
var base_color = Color(0.055, 0.075, 0.18, 1.0)
var draw_color = base_color
var route_width = 6.0
var head_length = 15.0
var head_half_width = 8.5
var motion_offset = 0.0
var busy = false

func setup(points, direction, width_value, color_value):
    route_points = PackedVector2Array(points)
    exit_dir = Vector2(direction.x, direction.y).normalized()
    route_width = width_value
    # Bigger triangle head so the route end is immediately distinguishable
    # from its tail, especially on dense levels.
    head_length = max(13.5, width_value * 2.65)
    head_half_width = max(8.0, width_value * 1.60)
    base_color = color_value
    draw_color = base_color
    _rebuild_lengths()
    queue_redraw()

func _rebuild_lengths():
    cumulative = PackedFloat32Array()
    cumulative.append(0.0)
    total_length = 0.0
    for i in range(route_points.size() - 1):
        total_length += route_points[i].distance_to(route_points[i + 1])
        cumulative.append(total_length)

func _sample_distance(distance):
    if route_points.is_empty():
        return Vector2.ZERO
    if distance <= 0.0:
        var start_dir = Vector2.RIGHT
        if route_points.size() > 1:
            start_dir = (route_points[1] - route_points[0]).normalized()
        return route_points[0] + start_dir * distance
    if distance >= total_length:
        return route_points[route_points.size() - 1] + exit_dir * (distance - total_length)
    for i in range(route_points.size() - 1):
        var a_len = cumulative[i]
        var b_len = cumulative[i + 1]
        if distance <= b_len:
            var span = max(0.001, b_len - a_len)
            var t = (distance - a_len) / span
            return route_points[i].lerp(route_points[i + 1], t)
    return route_points[route_points.size() - 1]

func _sample_direction(distance):
    if route_points.size() < 2:
        return exit_dir
    if distance >= total_length - 0.001:
        return exit_dir
    if distance <= 0.0:
        return (route_points[1] - route_points[0]).normalized()
    for i in range(route_points.size() - 1):
        if distance <= cumulative[i + 1]:
            return (route_points[i + 1] - route_points[i]).normalized()
    return exit_dir

func _visible_polyline(start_distance, end_distance):
    var result = PackedVector2Array()
    result.append(_sample_distance(start_distance))
    for i in range(1, route_points.size() - 1):
        var d = cumulative[i]
        if d > start_distance and d < end_distance:
            result.append(route_points[i])
    if total_length > start_distance and total_length < end_distance:
        result.append(route_points[route_points.size() - 1])
    result.append(_sample_distance(end_distance))
    return result

func _draw():
    if route_points.size() < 2:
        return
    var start_distance = motion_offset
    var end_distance = motion_offset + total_length
    var visible = _visible_polyline(start_distance, end_distance)
    if visible.size() >= 2:
        draw_polyline(visible, draw_color, route_width, true)

    var base = _sample_distance(end_distance)
    var direction = _sample_direction(end_distance)
    var perp = Vector2(-direction.y, direction.x)
    var tip = base + direction * head_length
    var left = base + perp * head_half_width
    var right = base - perp * head_half_width
    draw_colored_polygon(PackedVector2Array([tip, left, right]), draw_color)

func _set_motion(value):
    motion_offset = value
    queue_redraw()

func animate_escape(distance):
    if busy:
        return
    busy = true
    # V14: much faster train movement. The route remains visible until the
    # tail has followed every bend and fully cleared the board.
    var duration = clamp(distance / 2600.0, 0.16, 0.62)
    var tween = create_tween()
    tween.tween_method(Callable(self, "_set_motion"), 0.0, distance, duration).set_trans(Tween.TRANS_LINEAR)
    tween.tween_callback(func():
        escape_finished.emit(self)
        queue_free()
    )

func animate_block(distance):
    if busy:
        return
    busy = true
    draw_color = Color(0.88, 0.12, 0.14, 1.0)
    queue_redraw()
    var tween = create_tween()
    tween.tween_method(Callable(self, "_set_motion"), 0.0, distance, 0.12).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
    tween.tween_method(Callable(self, "_set_motion"), distance, 0.0, 0.16).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    tween.tween_callback(func():
        draw_color = base_color
        busy = false
        queue_redraw()
    )

func flash_hint():
    if busy:
        return
    var original = draw_color
    draw_color = Color(0.18, 0.75, 0.22, 1.0)
    queue_redraw()
    var tween = create_tween()
    tween.tween_interval(0.55)
    tween.tween_callback(func():
        draw_color = original
        queue_redraw()
    )

func distance_to_route(point):
    var best = INF
    for i in range(route_points.size() - 1):
        var a = route_points[i]
        var b = route_points[i + 1]
        var ab = b - a
        var denom = ab.length_squared()
        var t = 0.0
        if denom > 0.001:
            t = clamp((point - a).dot(ab) / denom, 0.0, 1.0)
        var closest = a + ab * t
        best = min(best, point.distance_to(closest))

    # The triangle is a very common touch target. Include the full head axis
    # instead of measuring only from its base as in V12.
    var head_base = route_points[route_points.size() - 1]
    var head_tip = head_base + exit_dir * head_length
    var head_axis = head_tip - head_base
    var head_denom = head_axis.length_squared()
    var head_t = 0.0
    if head_denom > 0.001:
        head_t = clamp((point - head_base).dot(head_axis) / head_denom, 0.0, 1.0)
    var closest_head = head_base + head_axis * head_t
    best = min(best, point.distance_to(closest_head))
    return best
