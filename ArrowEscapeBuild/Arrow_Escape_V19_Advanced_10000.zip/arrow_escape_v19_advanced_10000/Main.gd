extends Node2D

const RoutePiece = preload("res://RoutePiece.gd")
const WorldData = preload("res://WorldData.gd")

const BASE_WORLDS = 50
const ADVANCED_WORLDS = 500
const TOTAL_WORLDS = 550
const LEVELS_PER_WORLD = 20
const BASE_LEVELS = 1000
const ADVANCED_LEVELS = 10000
const TOTAL_LEVELS = 11000

const ARROW_COLOR = Color(0.055, 0.075, 0.18, 1.0)
const GRID_DOT_COLOR = Color(0.62, 0.69, 0.82, 0.12)
const SHAPE_FILL_COLORS = [
    Color(0.96, 0.985, 1.0, 0.90),
    Color(0.985, 0.965, 1.0, 0.90),
    Color(0.965, 1.0, 0.975, 0.90),
    Color(1.0, 0.985, 0.955, 0.90),
    Color(0.955, 0.985, 0.985, 0.90),
    Color(1.0, 0.965, 0.975, 0.90)
]
const SHAPE_BORDER_COLORS = [
    Color(0.43, 0.62, 0.88, 0.32),
    Color(0.64, 0.47, 0.88, 0.30),
    Color(0.36, 0.72, 0.57, 0.30),
    Color(0.92, 0.62, 0.31, 0.30)
]
const FIRST_WORLD_ROUTE_TARGETS = [14, 26, 40, 56, 74, 94, 116, 140, 166, 194, 224, 256, 290, 326, 364, 402, 440, 478, 516, 554]

var stage = 1
var remaining = 0
var grid_w = 24
var grid_h = 34
var cell_size = 32.0
var board_origin = Vector2.ZERO
var board_rect = Rect2(54, 220, 972, 1460)

var routes = []
var route_cells = {}
var route_region = {}
var occupancy = {}
var region_map = {}
var cells_by_region = {}
var valid_cells = []
var shape_specs = []
var stage_transition = false

var stage_label
var progress_label
var density_label
var world_label
var message_label
var hint_button
var restart_button
var stars_bar
var star_labels = []
var lose_panel
var lose_label
var replay_button
var zoom_in_button
var zoom_out_button
var camera_2d
var view_reset_button
var camera_fit_zoom = 1.0

var lives_left = 5
var max_lives = 5
var game_over = false
var pinch_last_distance = -1.0
var pinch_last_center = Vector2.ZERO
var single_pan_active = false
var gesture_had_multitouch = false

var press_start = Vector2.ZERO
var press_travel = 0.0
var touches = {}

func _ready():
    _create_camera()
    _create_ui()
    stage = _load_saved_stage()
    _load_stage(stage)


func _create_camera():
    camera_2d = Camera2D.new()
    camera_2d.enabled = true
    camera_2d.position = Vector2(540, 960)
    camera_2d.zoom = Vector2.ONE
    add_child(camera_2d)

func _style_button(button, fill_color, border_color, font_color := Color(1,1,1,1), radius := 22):
    var normal = StyleBoxFlat.new()
    normal.bg_color = fill_color
    normal.border_width_left = 2
    normal.border_width_top = 2
    normal.border_width_right = 2
    normal.border_width_bottom = 2
    normal.border_color = border_color
    normal.corner_radius_top_left = radius
    normal.corner_radius_top_right = radius
    normal.corner_radius_bottom_right = radius
    normal.corner_radius_bottom_left = radius
    var hover = normal.duplicate()
    hover.bg_color = fill_color.lightened(0.10)
    var pressed = normal.duplicate()
    pressed.bg_color = fill_color.darkened(0.10)
    var focus = normal.duplicate()
    focus.border_width_left = 3
    focus.border_width_top = 3
    focus.border_width_right = 3
    focus.border_width_bottom = 3
    button.add_theme_stylebox_override("normal", normal)
    button.add_theme_stylebox_override("hover", hover)
    button.add_theme_stylebox_override("pressed", pressed)
    button.add_theme_stylebox_override("focus", focus)
    button.add_theme_color_override("font_color", font_color)
    button.add_theme_color_override("font_hover_color", font_color)
    button.add_theme_color_override("font_pressed_color", font_color)

func _style_panel(panel):
    var style = StyleBoxFlat.new()
    style.bg_color = Color(1, 1, 1, 0.96)
    style.border_width_left = 3
    style.border_width_top = 3
    style.border_width_right = 3
    style.border_width_bottom = 3
    style.border_color = Color(0.84, 0.35, 0.35, 1)
    style.corner_radius_top_left = 28
    style.corner_radius_top_right = 28
    style.corner_radius_bottom_right = 28
    style.corner_radius_bottom_left = 28
    panel.add_theme_stylebox_override("panel", style)

func _reset_camera_view():
    if camera_2d == null:
        return
    camera_2d.position = board_rect.position + board_rect.size * 0.5
    var fit_x = 950.0 / max(1.0, board_rect.size.x)
    var fit_y = 1370.0 / max(1.0, board_rect.size.y)
    camera_fit_zoom = clamp(min(1.0, fit_x, fit_y) * 0.96, 0.055, 1.0)
    camera_2d.zoom = Vector2(camera_fit_zoom, camera_fit_zoom)

func _clamp_camera_position():
    if camera_2d == null:
        return
    if camera_2d.zoom.x <= camera_fit_zoom * 1.02:
        camera_2d.position = board_rect.position + board_rect.size * 0.5
        return
    camera_2d.position.x = clamp(camera_2d.position.x, board_rect.position.x, board_rect.end.x)
    camera_2d.position.y = clamp(camera_2d.position.y, board_rect.position.y, board_rect.end.y)

func _pan_view(screen_delta):
    if camera_2d == null:
        return
    if camera_2d.zoom.x <= camera_fit_zoom * 1.02:
        return
    camera_2d.position -= screen_delta / max(0.001, camera_2d.zoom.x)
    _clamp_camera_position()

func _apply_zoom(multiplier):
    if camera_2d == null:
        return
    var z = clamp(camera_2d.zoom.x * multiplier, 0.05, 8.0)
    camera_2d.zoom = Vector2(z, z)
    _clamp_camera_position()

func _screen_to_world(screen_point):
    return get_canvas_transform().affine_inverse() * screen_point

func _update_stars_ui():
    for i in range(star_labels.size()):
        var label = star_labels[i]
        if i < lives_left:
            label.text = "★"
            label.modulate = Color(1.0, 0.80, 0.18, 1.0)
        else:
            label.text = ""
            label.modulate = Color(1, 1, 1, 0)

func _consume_error():
    if game_over:
        return
    lives_left = max(0, lives_left - 1)
    _update_stars_ui()
    _update_ui()
    if lives_left <= 0:
        _show_loss()

func _show_loss():
    game_over = true
    stage_transition = true
    lose_label.text = "لقد خسرت"
    lose_panel.visible = true
    message_label.visible = false

func _create_ui():
    var layer = CanvasLayer.new()
    add_child(layer)
    var root = Control.new()
    root.set_anchors_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    layer.add_child(root)

    world_label = Label.new()
    world_label.set_anchors_preset(Control.PRESET_TOP_WIDE)
    world_label.offset_left = 170
    world_label.offset_top = 14
    world_label.offset_right = -170
    world_label.offset_bottom = 48
    world_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    world_label.add_theme_font_size_override("font_size", 22)
    world_label.add_theme_color_override("font_color", Color(0.36, 0.42, 0.64, 1))
    world_label.text = "العالم 1 • الأشكال الهندسية"
    root.add_child(world_label)

    stage_label = Label.new()
    stage_label.set_anchors_preset(Control.PRESET_TOP_WIDE)
    stage_label.offset_left = 150
    stage_label.offset_top = 44
    stage_label.offset_right = -150
    stage_label.offset_bottom = 92
    stage_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    stage_label.add_theme_font_size_override("font_size", 32)
    stage_label.add_theme_color_override("font_color", Color(0.10, 0.13, 0.28, 1))
    root.add_child(stage_label)

    progress_label = Label.new()
    progress_label.set_anchors_preset(Control.PRESET_TOP_WIDE)
    progress_label.offset_left = 150
    progress_label.offset_top = 88
    progress_label.offset_right = -150
    progress_label.offset_bottom = 124
    progress_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    progress_label.add_theme_font_size_override("font_size", 22)
    progress_label.add_theme_color_override("font_color", Color(0.34, 0.38, 0.55, 1))
    root.add_child(progress_label)

    stars_bar = HBoxContainer.new()
    stars_bar.set_anchors_preset(Control.PRESET_TOP_WIDE)
    stars_bar.offset_left = 310
    stars_bar.offset_top = 126
    stars_bar.offset_right = -310
    stars_bar.offset_bottom = 172
    stars_bar.alignment = BoxContainer.ALIGNMENT_CENTER
    stars_bar.add_theme_constant_override("separation", 8)
    root.add_child(stars_bar)
    star_labels.clear()
    for i in range(max_lives):
        var star = Label.new()
        star.text = "★"
        star.custom_minimum_size = Vector2(42, 42)
        star.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        star.add_theme_font_size_override("font_size", 34)
        star.modulate = Color(1.0, 0.80, 0.18, 1.0)
        stars_bar.add_child(star)
        star_labels.append(star)

    density_label = Label.new()
    density_label.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
    density_label.offset_left = 72
    density_label.offset_top = -174
    density_label.offset_right = -72
    density_label.offset_bottom = -116
    density_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    density_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    density_label.add_theme_font_size_override("font_size", 18)
    density_label.add_theme_color_override("font_color", Color(0.38, 0.41, 0.56, 1))
    root.add_child(density_label)

    message_label = Label.new()
    message_label.set_anchors_preset(Control.PRESET_CENTER)
    message_label.offset_left = -440
    message_label.offset_top = -72
    message_label.offset_right = 440
    message_label.offset_bottom = 72
    message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    message_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    message_label.add_theme_font_size_override("font_size", 40)
    message_label.add_theme_color_override("font_color", Color(0.10, 0.58, 0.29, 1))
    message_label.visible = false
    root.add_child(message_label)


    restart_button = Button.new()
    restart_button.text = "↻"
    restart_button.set_anchors_preset(Control.PRESET_TOP_LEFT)
    restart_button.offset_left = 20
    restart_button.offset_top = 24
    restart_button.offset_right = 98
    restart_button.offset_bottom = 96
    restart_button.add_theme_font_size_override("font_size", 34)
    _style_button(restart_button, Color(0.49, 0.53, 0.62, 1), Color(0.35, 0.39, 0.48, 1))
    restart_button.pressed.connect(func(): _load_stage(stage))
    root.add_child(restart_button)

    hint_button = Button.new()
    hint_button.text = "💡 تلميح"
    hint_button.set_anchors_preset(Control.PRESET_TOP_RIGHT)
    hint_button.offset_left = -214
    hint_button.offset_top = 24
    hint_button.offset_right = -28
    hint_button.offset_bottom = 96
    hint_button.add_theme_font_size_override("font_size", 24)
    _style_button(hint_button, Color(0.98, 0.73, 0.18, 1), Color(0.83, 0.54, 0.05, 1), Color(0.24, 0.17, 0.02, 1))
    hint_button.pressed.connect(_show_hint)
    root.add_child(hint_button)

    lose_panel = PanelContainer.new()
    lose_panel.set_anchors_preset(Control.PRESET_CENTER)
    lose_panel.offset_left = -245
    lose_panel.offset_top = -150
    lose_panel.offset_right = 245
    lose_panel.offset_bottom = 150
    lose_panel.visible = false
    _style_panel(lose_panel)
    root.add_child(lose_panel)

    var lose_v = VBoxContainer.new()
    lose_v.alignment = BoxContainer.ALIGNMENT_CENTER
    lose_v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    lose_v.size_flags_vertical = Control.SIZE_EXPAND_FILL
    lose_v.add_theme_constant_override("separation", 18)
    lose_panel.add_child(lose_v)

    lose_label = Label.new()
    lose_label.text = "لقد خسرت"
    lose_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    lose_label.add_theme_font_size_override("font_size", 38)
    lose_label.add_theme_color_override("font_color", Color(0.72, 0.16, 0.16, 1))
    lose_v.add_child(lose_label)

    var lose_info = Label.new()
    lose_info.text = "استهلكت 5 أخطاء. أعد المحاولة من جديد."
    lose_info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    lose_info.add_theme_font_size_override("font_size", 22)
    lose_info.add_theme_color_override("font_color", Color(0.34, 0.38, 0.55, 1))
    lose_v.add_child(lose_info)

    replay_button = Button.new()
    replay_button.text = "إعادة اللعب"
    replay_button.custom_minimum_size = Vector2(230, 66)
    replay_button.add_theme_font_size_override("font_size", 26)
    _style_button(replay_button, Color(0.16, 0.69, 0.37, 1), Color(0.08, 0.49, 0.25, 1))
    replay_button.pressed.connect(func(): _load_stage(stage))
    lose_v.add_child(replay_button)

    zoom_in_button = Button.new()
    zoom_in_button.text = "+"
    zoom_in_button.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
    zoom_in_button.offset_left = -105
    zoom_in_button.offset_top = -280
    zoom_in_button.offset_right = -30
    zoom_in_button.offset_bottom = -210
    zoom_in_button.add_theme_font_size_override("font_size", 34)
    _style_button(zoom_in_button, Color(0.18, 0.56, 0.92, 0.96), Color(0.08, 0.38, 0.72, 1))
    zoom_in_button.pressed.connect(func(): _apply_zoom(1.22))
    root.add_child(zoom_in_button)

    zoom_out_button = Button.new()
    zoom_out_button.text = "−"
    zoom_out_button.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
    zoom_out_button.offset_left = -105
    zoom_out_button.offset_top = -198
    zoom_out_button.offset_right = -30
    zoom_out_button.offset_bottom = -128
    zoom_out_button.add_theme_font_size_override("font_size", 34)
    _style_button(zoom_out_button, Color(0.25, 0.72, 0.82, 0.96), Color(0.10, 0.52, 0.62, 1))
    zoom_out_button.pressed.connect(func(): _apply_zoom(0.82))
    root.add_child(zoom_out_button)


    view_reset_button = Button.new()
    view_reset_button.text = "◎"
    view_reset_button.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
    view_reset_button.offset_left = -105
    view_reset_button.offset_top = -116
    view_reset_button.offset_right = -30
    view_reset_button.offset_bottom = -46
    view_reset_button.add_theme_font_size_override("font_size", 30)
    _style_button(view_reset_button, Color(0.55, 0.45, 0.90, 0.96), Color(0.39, 0.29, 0.75, 1))
    view_reset_button.pressed.connect(_reset_camera_view)
    root.add_child(view_reset_button)

func _world_number(global_level):
    return int(floor(float(global_level - 1) / float(LEVELS_PER_WORLD))) + 1

func _local_level(global_level):
    return int((global_level - 1) % LEVELS_PER_WORLD) + 1

func _difficulty_name(global_level):
    var local_level = _local_level(global_level)
    if local_level <= 5:
        return "سهل"
    if local_level <= 10:
        return "متوسط"
    if local_level <= 15:
        return "صعب"
    return "صعب للغاية"

func _stage_profile(global_level):
    var world = _world_number(global_level)
    var local_level = _local_level(global_level)

    if global_level <= BASE_LEVELS:
        var global_t = float(global_level - 1) / float(BASE_LEVELS - 1)
        var route_target = 0
        var width = 0
        var height = 0
        var min_len = 2
        var max_len = 0
        var turn_chance = 0.0
        var max_turns = 0
        if global_level <= 20:
            route_target = FIRST_WORLD_ROUTE_TARGETS[local_level - 1]
            width = 22 + int(ceil(float(local_level) * 1.55))
            height = 31 + int(ceil(float(local_level) * 1.90))
            max_len = 4 + int(ceil(float(local_level) * 0.55))
            turn_chance = min(0.90, 0.20 + float(local_level) * 0.034)
            max_turns = 1 + int(floor(float(local_level) / 2.5))
        else:
            var extra = global_level - 20
            route_target = min(1020, 554 + int(ceil(float(extra) * 0.48)))
            width = 53 + int(ceil(float(extra) * 0.055))
            height = 69 + int(ceil(float(extra) * 0.085))
            min_len = 2 + int(floor(float(extra) / 260.0))
            max_len = 15 + int(floor(float(extra) * 0.025))
            turn_chance = min(0.98, 0.88 + float(extra) * 0.00010)
            max_turns = 9 + int(floor(float(extra) / 70.0))
        return {
            "routes": route_target,
            "w": width,
            "h": height,
            "min_len": min_len,
            "max_len": max_len,
            "turn_chance": turn_chance,
            "max_turns": max_turns,
            "arena_scale": 1.0 + global_t * 1.55,
            "world": world,
            "local": local_level
        }

    var advanced_index = global_level - BASE_LEVELS
    var advanced_t = float(advanced_index - 1) / float(max(1, ADVANCED_LEVELS - 1))
    var advanced_world = world - BASE_WORLDS
    var world_t = float(max(0, advanced_world - 1)) / float(max(1, ADVANCED_WORLDS - 1))
    var local_t = float(local_level - 1) / 19.0
    var route_target = min(2600, 1020 + int(round(advanced_t * 1500.0)))
    var width = 108 + int(round(advanced_t * 132.0))
    var height = 153 + int(round(advanced_t * 207.0))
    var min_len = 5 + int(round(world_t * 6.0))
    var max_len = 40 + int(round(world_t * 86.0)) + int(round(local_t * 22.0))
    var turn_chance = clamp(0.58 + world_t * 0.28 + local_t * 0.12, 0.58, 0.985)
    var max_turns = 5 + int(round(world_t * 72.0)) + int(round(local_t * 18.0))
    var arena_scale = 2.55 + advanced_t * 5.75
    return {
        "routes": route_target,
        "w": width,
        "h": height,
        "min_len": min_len,
        "max_len": max_len,
        "turn_chance": turn_chance,
        "max_turns": max_turns,
        "arena_scale": arena_scale,
        "world": world,
        "local": local_level
    }

func _shape(kind, cx, cy, sx, sy, rot = 0.0):
    return {
        "type": kind,
        "center": Vector2(cx, cy),
        "size": Vector2(sx, sy),
        "rotation": deg_to_rad(rot)
    }

func _geometry_layout(level):
    match level:
        1:
            return [_shape("circle", 0.31, 0.47, 0.40, 0.31), _shape("rect", 0.72, 0.50, 0.34, 0.31)]
        2:
            return [_shape("triangle", 0.23, 0.34, 0.32, 0.28), _shape("circle", 0.66, 0.31, 0.29, 0.24), _shape("rect", 0.50, 0.69, 0.38, 0.25)]
        3:
            return [_shape("star", 0.24, 0.34, 0.34, 0.29, -10), _shape("rect", 0.68, 0.34, 0.39, 0.22, 8), _shape("triangle", 0.49, 0.71, 0.38, 0.27, 180)]
        4:
            return [_shape("hex", 0.50, 0.35, 0.45, 0.30), _shape("circle", 0.23, 0.72, 0.29, 0.22), _shape("circle", 0.77, 0.72, 0.29, 0.22)]
        5:
            return [_shape("star", 0.50, 0.42, 0.47, 0.35, -8), _shape("diamond", 0.19, 0.78, 0.23, 0.17), _shape("triangle", 0.50, 0.79, 0.24, 0.18), _shape("circle", 0.81, 0.78, 0.23, 0.17)]
        6:
            return [_shape("diamond", 0.25, 0.31, 0.32, 0.25), _shape("rect", 0.72, 0.30, 0.34, 0.24, 7), _shape("circle", 0.29, 0.72, 0.31, 0.23), _shape("hex", 0.72, 0.71, 0.34, 0.25)]
        7:
            return [_shape("triangle", 0.25, 0.25, 0.31, 0.22), _shape("triangle", 0.72, 0.25, 0.31, 0.22, 180), _shape("triangle", 0.25, 0.70, 0.31, 0.22, 180), _shape("triangle", 0.72, 0.70, 0.31, 0.22)]
        8:
            return [_shape("spiral", 0.50, 0.48, 0.66, 0.56), _shape("rect", 0.18, 0.83, 0.22, 0.14), _shape("rect", 0.82, 0.83, 0.22, 0.14)]
        9:
            return [_shape("hex", 0.25, 0.29, 0.33, 0.24), _shape("hex", 0.73, 0.29, 0.33, 0.24, 30), _shape("star", 0.28, 0.72, 0.35, 0.26), _shape("circle", 0.74, 0.71, 0.31, 0.23)]
        10:
            return [_shape("star", 0.20, 0.25, 0.29, 0.21), _shape("circle", 0.51, 0.23, 0.27, 0.20), _shape("diamond", 0.81, 0.27, 0.27, 0.20), _shape("hex", 0.31, 0.68, 0.34, 0.25), _shape("rect", 0.72, 0.69, 0.37, 0.23, -7)]
        11:
            return [_shape("star", 0.50, 0.37, 0.55, 0.39), _shape("circle", 0.18, 0.76, 0.24, 0.18), _shape("circle", 0.50, 0.79, 0.25, 0.18), _shape("circle", 0.82, 0.76, 0.24, 0.18)]
        12:
            return [_shape("rect", 0.22, 0.27, 0.31, 0.21), _shape("circle", 0.50, 0.27, 0.26, 0.19), _shape("rect", 0.79, 0.27, 0.31, 0.21), _shape("circle", 0.28, 0.70, 0.31, 0.23), _shape("diamond", 0.70, 0.70, 0.34, 0.25)]
        13:
            return [_shape("maze", 0.50, 0.49, 0.78, 0.66), _shape("circle", 0.18, 0.84, 0.19, 0.13), _shape("triangle", 0.82, 0.84, 0.21, 0.14)]
        14:
            return [_shape("hex", 0.19, 0.25, 0.27, 0.19), _shape("diamond", 0.50, 0.24, 0.29, 0.20), _shape("oct", 0.81, 0.25, 0.27, 0.19), _shape("triangle", 0.28, 0.67, 0.35, 0.25), _shape("star", 0.70, 0.68, 0.37, 0.27)]
        15:
            return [_shape("flower", 0.50, 0.47, 0.72, 0.57), _shape("diamond", 0.18, 0.84, 0.20, 0.13), _shape("diamond", 0.82, 0.84, 0.20, 0.13)]
        16:
            return [_shape("star", 0.50, 0.36, 0.63, 0.43), _shape("hex", 0.20, 0.77, 0.26, 0.18), _shape("hex", 0.50, 0.78, 0.26, 0.18, 30), _shape("hex", 0.80, 0.77, 0.26, 0.18)]
        17:
            return [_shape("oct", 0.18, 0.23, 0.26, 0.18), _shape("triangle", 0.49, 0.22, 0.27, 0.18), _shape("star", 0.81, 0.23, 0.26, 0.18), _shape("diamond", 0.23, 0.65, 0.31, 0.22), _shape("hex", 0.55, 0.67, 0.31, 0.22), _shape("circle", 0.82, 0.70, 0.26, 0.19)]
        18:
            return [_shape("rings", 0.50, 0.43, 0.74, 0.56), _shape("star", 0.20, 0.81, 0.25, 0.17), _shape("star", 0.50, 0.83, 0.25, 0.17, 20), _shape("star", 0.80, 0.81, 0.25, 0.17, -20)]
        19:
            return [_shape("maze", 0.33, 0.36, 0.56, 0.45), _shape("flower", 0.74, 0.34, 0.43, 0.35), _shape("star", 0.25, 0.78, 0.33, 0.23), _shape("hex", 0.57, 0.77, 0.30, 0.21), _shape("diamond", 0.83, 0.78, 0.25, 0.18)]
        20:
            return [_shape("star", 0.25, 0.24, 0.38, 0.26), _shape("rings", 0.68, 0.25, 0.49, 0.33), _shape("flower", 0.25, 0.65, 0.42, 0.31), _shape("maze", 0.65, 0.63, 0.55, 0.39), _shape("hex", 0.18, 0.88, 0.23, 0.13), _shape("diamond", 0.50, 0.88, 0.23, 0.13), _shape("triangle", 0.82, 0.88, 0.23, 0.13)]
    return [_shape("circle", 0.5, 0.5, 0.7, 0.6)]

func _formation_slots(count):
    match count:
        1:
            return [{"c":Vector2(0.50,0.50),"s":Vector2(0.80,0.70)}]
        2:
            return [{"c":Vector2(0.30,0.48),"s":Vector2(0.48,0.38)}, {"c":Vector2(0.72,0.50),"s":Vector2(0.44,0.35)}]
        3:
            return [{"c":Vector2(0.50,0.28),"s":Vector2(0.48,0.34)}, {"c":Vector2(0.26,0.68),"s":Vector2(0.39,0.29)}, {"c":Vector2(0.74,0.69),"s":Vector2(0.39,0.29)}]
        4:
            return [{"c":Vector2(0.26,0.28),"s":Vector2(0.38,0.28)}, {"c":Vector2(0.74,0.28),"s":Vector2(0.38,0.28)}, {"c":Vector2(0.26,0.70),"s":Vector2(0.38,0.28)}, {"c":Vector2(0.74,0.70),"s":Vector2(0.38,0.28)}]
        5:
            return [{"c":Vector2(0.50,0.23),"s":Vector2(0.40,0.27)}, {"c":Vector2(0.20,0.52),"s":Vector2(0.32,0.24)}, {"c":Vector2(0.50,0.52),"s":Vector2(0.34,0.25)}, {"c":Vector2(0.80,0.52),"s":Vector2(0.32,0.24)}, {"c":Vector2(0.50,0.82),"s":Vector2(0.39,0.24)}]
        6:
            return [{"c":Vector2(0.22,0.24),"s":Vector2(0.32,0.23)}, {"c":Vector2(0.50,0.23),"s":Vector2(0.32,0.23)}, {"c":Vector2(0.78,0.24),"s":Vector2(0.32,0.23)}, {"c":Vector2(0.22,0.70),"s":Vector2(0.32,0.23)}, {"c":Vector2(0.50,0.71),"s":Vector2(0.32,0.23)}, {"c":Vector2(0.78,0.70),"s":Vector2(0.32,0.23)}]
        7:
            return [{"c":Vector2(0.18,0.22),"s":Vector2(0.29,0.20)}, {"c":Vector2(0.50,0.20),"s":Vector2(0.32,0.22)}, {"c":Vector2(0.82,0.22),"s":Vector2(0.29,0.20)}, {"c":Vector2(0.28,0.51),"s":Vector2(0.32,0.22)}, {"c":Vector2(0.72,0.51),"s":Vector2(0.32,0.22)}, {"c":Vector2(0.24,0.81),"s":Vector2(0.30,0.19)}, {"c":Vector2(0.70,0.81),"s":Vector2(0.36,0.20)}]
        _:
            return [{"c":Vector2(0.18,0.20),"s":Vector2(0.28,0.19)}, {"c":Vector2(0.50,0.19),"s":Vector2(0.29,0.19)}, {"c":Vector2(0.82,0.20),"s":Vector2(0.28,0.19)}, {"c":Vector2(0.18,0.50),"s":Vector2(0.28,0.19)}, {"c":Vector2(0.50,0.50),"s":Vector2(0.29,0.19)}, {"c":Vector2(0.82,0.50),"s":Vector2(0.28,0.19)}, {"c":Vector2(0.28,0.81),"s":Vector2(0.32,0.20)}, {"c":Vector2(0.72,0.81),"s":Vector2(0.32,0.20)}]

func _is_tall_shape(kind):
    return kind in ["giraffe","tower","skyscraper","lighthouse","bottle","rocket","tree","palm","cactus","carrot","lamp"]

func _is_wide_shape(kind):
    return kind in ["elephant","car","sportcar","pickup","van","truck","tanker","bus","train","metro","tram","plane","ship","boat","submarine","crocodile","lizard","bridge","dolphin","fish"]

func _adapt_slot_for_shape(slot, kind, count):
    var center = slot["c"]
    var size = slot["s"]
    if count == 1:
        if _is_tall_shape(kind):
            size = Vector2(0.54, 0.86)
        elif _is_wide_shape(kind):
            size = Vector2(0.90, 0.54)
        else:
            size = Vector2(0.82, 0.72)
    elif count == 2:
        if _is_tall_shape(kind):
            size = Vector2(min(size.x, 0.38), 0.76)
        elif _is_wide_shape(kind):
            size = Vector2(0.46, min(size.y, 0.58))
    return {"c":center, "s":size}

func _layout_for_stage(global_level):
    var world = _world_number(global_level)
    var local_level = _local_level(global_level)
    if world == 1:
        return _geometry_layout(local_level)
    if global_level <= BASE_LEVELS:
        var old_count = WorldData.formation_count(local_level, world)
        var old_slots = _formation_slots(old_count)
        var old_pool = WorldData.shape_pool(world)
        var old_rng = RandomNumberGenerator.new()
        old_rng.seed = 901013 + global_level * 3571
        var old_result = []
        for i in range(min(old_count, old_slots.size())):
            var old_slot = old_slots[i]
            var old_kind = old_pool[(i + local_level * 2 + world * 3) % old_pool.size()]
            var old_rot = old_rng.randf_range(-14.0, 14.0)
            if old_kind in ["car","sportcar","pickup","van","truck","tanker","bus","train","metro","tram","bike","motorcycle","scooter","plane","ship","boat","submarine","bridge","house","factory"]:
                old_rot = old_rng.randf_range(-6.0, 6.0)
            var size_scale = 1.0 + min(0.12, float(local_level - 1) * 0.004)
            old_result.append(_shape(old_kind, old_slot["c"].x, old_slot["c"].y, old_slot["s"].x * size_scale, old_slot["s"].y * size_scale, old_rot))
        return old_result

    var count = WorldData.formation_count(local_level, world)
    var slots = _formation_slots(count)
    var featured = WorldData.featured_shapes(world, count)
    var rng = RandomNumberGenerator.new()
    rng.seed = 730001 + world * 11939
    var result = []
    var usable_count = min(count, min(slots.size(), featured.size()))
    for i in range(usable_count):
        var kind = featured[i]
        var adapted = _adapt_slot_for_shape(slots[i], kind, count)
        var rot = rng.randf_range(-8.0, 8.0)
        if kind in ["car","sportcar","pickup","van","truck","tanker","bus","train","metro","tram","bike","motorcycle","scooter","plane","ship","boat","submarine","bridge","house","factory","giraffe","elephant"]:
            rot = rng.randf_range(-3.0, 3.0)
        result.append(_shape(kind, adapted["c"].x, adapted["c"].y, adapted["s"].x, adapted["s"].y, rot))
    return result

func _set_dynamic_board(profile):
    var scale = float(profile["arena_scale"])
    var size = Vector2(972.0, 1460.0) * scale
    board_rect = Rect2(Vector2(540, 960) - size * 0.5, size)

func _load_stage(new_stage):
    stage_transition = false
    stage = clamp(int(new_stage), 1, TOTAL_LEVELS)
    for route in routes:
        if is_instance_valid(route):
            route.queue_free()
    routes.clear()
    route_cells.clear()
    route_region.clear()
    occupancy.clear()
    region_map.clear()
    cells_by_region.clear()
    valid_cells.clear()

    var profile = _stage_profile(stage)
    grid_w = profile["w"]
    grid_h = profile["h"]
    _set_dynamic_board(profile)
    shape_specs = _layout_for_stage(stage)
    _fit_board()
    _build_region_map()

    var rng = RandomNumberGenerator.new()
    rng.seed = 59117 + stage * 24593
    var generated = _generate_routes(profile, rng)

    for data in generated:
        var piece = RoutePiece.new()
        var points = []
        for cell in data["cells"]:
            points.append(_cell_to_point(cell))
        var line_width = clamp(cell_size * 0.17, 3.5, 6.8)
        piece.setup(points, data["exit"], line_width, ARROW_COLOR)
        add_child(piece)
        piece.escape_finished.connect(_on_route_escape_finished)
        routes.append(piece)
        route_cells[piece] = data["cells"]
        route_region[piece] = data["region"]
        for cell in data["cells"]:
            occupancy[cell] = piece

    remaining = routes.size()
    lives_left = max_lives
    game_over = false
    lose_panel.visible = false
    message_label.visible = false
    _reset_camera_view()
    _update_stars_ui()
    _update_ui()
    queue_redraw()

func _fit_board():
    var usable = board_rect.size - Vector2(12, 12)
    cell_size = min(usable.x / max(1.0, float(grid_w - 1)), usable.y / max(1.0, float(grid_h - 1)))
    var actual = Vector2(float(grid_w - 1) * cell_size, float(grid_h - 1) * cell_size)
    board_origin = board_rect.position + (board_rect.size - actual) * 0.5

func _draw():
    var backdrop = board_rect.grow(max(board_rect.size.x, board_rect.size.y) * 0.22)
    draw_rect(backdrop, _background_color_for_stage(stage), true)
    _draw_background_decor()
    draw_rect(board_rect, Color(1.0, 1.0, 1.0, 0.34), true)

func _background_color_for_stage(level):
    var palette = WorldData.palette(_world_number(level))
    return palette["bg"]

func _draw_background_decor():
    var world = _world_number(stage)
    var local_level = _local_level(stage)
    var palette = WorldData.palette(world)
    var decor_colors = palette["decor"]
    var pool = WorldData.shape_pool(world)
    var rng = RandomNumberGenerator.new()
    rng.seed = 880301 + stage * 7739

    var bubble_count = 20 + int(local_level * 0.8) + min(world, 24)
    for i in range(bubble_count):
        var x = rng.randf_range(board_rect.position.x + 20.0, board_rect.end.x - 20.0)
        var y = rng.randf_range(board_rect.position.y + 10.0, board_rect.end.y - 10.0)
        var radius = rng.randf_range(24.0, 82.0) * (0.85 + float(world) * 0.004)
        var c = decor_colors[rng.randi_range(0, decor_colors.size() - 1)]
        c.a = rng.randf_range(0.13, 0.23)
        draw_circle(Vector2(x, y), radius, c)

    var mark_count = 10 + int(local_level / 2) + int(world / 3)
    for i in range(mark_count):
        var kind = pool[rng.randi_range(0, pool.size() - 1)]
        var spec = _shape(kind, rng.randf_range(0.04, 0.96), rng.randf_range(0.05, 0.95), rng.randf_range(0.035, 0.080), rng.randf_range(0.030, 0.070), rng.randf_range(-25.0, 25.0))
        var poly = _shape_polygon_pixels(spec)
        if poly.size() >= 3:
            var c = decor_colors[rng.randi_range(0, decor_colors.size() - 1)]
            c.a = rng.randf_range(0.07, 0.14)
            draw_colored_polygon(poly, c)

func _cell_to_point(cell):
    return board_origin + Vector2(float(cell.x) * cell_size, float(cell.y) * cell_size)

func _build_region_map():
    for i in range(shape_specs.size()):
        cells_by_region[i] = []

    for y in range(grid_h):
        for x in range(grid_w):
            var cell = Vector2i(x, y)
            var point = _cell_to_point(cell)
            var assigned = -1
            for i in range(shape_specs.size()):
                if _point_in_shape(point, shape_specs[i]):
                    assigned = i
                    break
            if assigned >= 0:
                region_map[cell] = assigned
                cells_by_region[assigned].append(cell)
                valid_cells.append(cell)

func _point_in_shape(point, spec):
    var poly = _shape_polygon_pixels(spec)
    return _point_in_polygon(point, poly)

func _point_in_polygon(point, poly):
    if poly.size() < 3:
        return false
    var inside = false
    var j = poly.size() - 1
    for i in range(poly.size()):
        var pi = poly[i]
        var pj = poly[j]
        if ((pi.y > point.y) != (pj.y > point.y)):
            var denom = pj.y - pi.y
            if abs(denom) < 0.00001:
                denom = 0.00001
            var x_cross = (pj.x - pi.x) * (point.y - pi.y) / denom + pi.x
            if point.x < x_cross:
                inside = not inside
        j = i
    return inside

func _shape_polygon_pixels(spec):
    var local = _shape_local_polygon(spec["type"])
    var result = PackedVector2Array()
    var center = board_rect.position + Vector2(spec["center"].x * board_rect.size.x, spec["center"].y * board_rect.size.y)
    var pixel_size = Vector2(spec["size"].x * board_rect.size.x, spec["size"].y * board_rect.size.y)
    var rot = float(spec["rotation"])
    for p in local:
        var q = Vector2(p.x * pixel_size.x, p.y * pixel_size.y).rotated(rot)
        result.append(center + q)
    return result

func _shape_local_polygon(kind):
    var pts = PackedVector2Array()
    match kind:
        "rect", "folder":
            pts = PackedVector2Array([Vector2(-0.50,-0.40), Vector2(0.50,-0.40), Vector2(0.50,0.40), Vector2(-0.50,0.40)])
        "circle", "ball", "donut", "planet":
            for i in range(40):
                var a = TAU * float(i) / 40.0
                pts.append(Vector2(cos(a), sin(a)) * 0.5)
        "triangle":
            pts = PackedVector2Array([Vector2(0,-0.52), Vector2(0.54,0.48), Vector2(-0.54,0.48)])
        "diamond":
            pts = PackedVector2Array([Vector2(0,-0.52), Vector2(0.52,0), Vector2(0,0.52), Vector2(-0.52,0)])
        "hex":
            for i in range(6):
                var a = -PI/2.0 + TAU * float(i) / 6.0
                pts.append(Vector2(cos(a), sin(a)) * 0.52)
        "oct":
            for i in range(8):
                var a = -PI/8.0 + TAU * float(i) / 8.0
                pts.append(Vector2(cos(a), sin(a)) * 0.52)
        "star":
            for i in range(10):
                var a = -PI/2.0 + TAU * float(i) / 10.0
                var r = 0.52 if i % 2 == 0 else 0.24
                pts.append(Vector2(cos(a), sin(a)) * r)
        "flower", "rose", "tulip", "sunflower":
            for i in range(48):
                var a = TAU * float(i) / 48.0
                var r = 0.36 + 0.13 * sin(a * 6.0)
                pts.append(Vector2(cos(a), sin(a)) * r)
        "rings", "spiral":
            for i in range(48):
                var a = TAU * float(i) / 48.0
                var r = 0.40 + 0.08 * sin(a * 7.0)
                pts.append(Vector2(cos(a), sin(a)) * r)
        "maze":
            pts = PackedVector2Array([Vector2(-0.50,-0.42), Vector2(0.35,-0.42), Vector2(0.35,-0.23), Vector2(0.50,-0.23), Vector2(0.50,0.42), Vector2(-0.18,0.42), Vector2(-0.18,0.26), Vector2(-0.50,0.26)])
        "heart":
            pts = PackedVector2Array([Vector2(0,0.48), Vector2(-0.48,0.05), Vector2(-0.44,-0.23), Vector2(-0.25,-0.44), Vector2(0,-0.28), Vector2(0.25,-0.44), Vector2(0.44,-0.23), Vector2(0.48,0.05)])
        "shield", "helmet":
            pts = PackedVector2Array([Vector2(-0.44,-0.40), Vector2(0.44,-0.40), Vector2(0.38,0.18), Vector2(0,0.52), Vector2(-0.38,0.18)])
        "crown":
            pts = PackedVector2Array([Vector2(-0.50,0.35), Vector2(-0.42,-0.28), Vector2(-0.18,-0.02), Vector2(0,-0.42), Vector2(0.18,-0.02), Vector2(0.42,-0.28), Vector2(0.50,0.35)])
        "bolt":
            pts = PackedVector2Array([Vector2(0.08,-0.52), Vector2(-0.30,0.02), Vector2(-0.04,0.02), Vector2(-0.18,0.50), Vector2(0.34,-0.10), Vector2(0.08,-0.10)])
        "key":
            pts = PackedVector2Array([Vector2(-0.48,-0.16), Vector2(-0.18,-0.16), Vector2(-0.18,-0.30), Vector2(0.18,-0.30), Vector2(0.40,-0.12), Vector2(0.40,0.12), Vector2(0.18,0.30), Vector2(-0.18,0.30), Vector2(-0.18,0.12), Vector2(-0.48,0.12)])
        "book":
            pts = PackedVector2Array([Vector2(-0.48,-0.38), Vector2(-0.03,-0.31), Vector2(0,-0.24), Vector2(0.03,-0.31), Vector2(0.48,-0.38), Vector2(0.48,0.38), Vector2(0.03,0.31), Vector2(0,0.38), Vector2(-0.03,0.31), Vector2(-0.48,0.38)])
        "pencil":
            pts = PackedVector2Array([Vector2(-0.48,-0.10), Vector2(0.28,-0.10), Vector2(0.50,0), Vector2(0.28,0.10), Vector2(-0.48,0.10)])
        "scissors":
            pts = PackedVector2Array([Vector2(-0.48,-0.28), Vector2(-0.15,-0.10), Vector2(0.48,-0.42), Vector2(0.10,0), Vector2(0.48,0.42), Vector2(-0.15,0.10), Vector2(-0.48,0.28), Vector2(-0.30,0), Vector2(-0.48,-0.28)])
        "cup", "glass":
            pts = PackedVector2Array([Vector2(-0.34,-0.38), Vector2(0.28,-0.38), Vector2(0.34,0.35), Vector2(-0.30,0.35), Vector2(-0.42,0.12), Vector2(-0.42,-0.08), Vector2(-0.34,-0.16)])
        "chair":
            pts = PackedVector2Array([Vector2(-0.36,-0.48), Vector2(0.20,-0.48), Vector2(0.20,-0.05), Vector2(0.40,-0.05), Vector2(0.40,0.12), Vector2(0.12,0.12), Vector2(0.12,0.48), Vector2(-0.02,0.48), Vector2(-0.02,0.12), Vector2(-0.36,0.12)])
        "lamp":
            pts = PackedVector2Array([Vector2(-0.28,-0.40), Vector2(0.28,-0.40), Vector2(0.18,-0.08), Vector2(0.06,-0.08), Vector2(0.06,0.36), Vector2(0.30,0.36), Vector2(0.30,0.48), Vector2(-0.30,0.48), Vector2(-0.30,0.36), Vector2(-0.06,0.36), Vector2(-0.06,-0.08), Vector2(-0.18,-0.08)])
        "clock":
            for i in range(36):
                var a = TAU * float(i) / 36.0
                pts.append(Vector2(cos(a), sin(a)) * 0.5)
        "bottle":
            pts = PackedVector2Array([Vector2(-0.12,-0.50), Vector2(0.12,-0.50), Vector2(0.12,-0.34), Vector2(0.22,-0.20), Vector2(0.26,0.44), Vector2(-0.26,0.44), Vector2(-0.22,-0.20), Vector2(-0.12,-0.34)])
        "pan":
            pts = PackedVector2Array([Vector2(-0.42,-0.25), Vector2(0.20,-0.25), Vector2(0.20,-0.12), Vector2(0.50,-0.05), Vector2(0.50,0.05), Vector2(0.20,0.12), Vector2(0.20,0.25), Vector2(-0.42,0.25)])
        "spoon", "fork":
            pts = PackedVector2Array([Vector2(-0.08,-0.50), Vector2(0.08,-0.50), Vector2(0.12,-0.14), Vector2(0.22,0.08), Vector2(0.18,0.42), Vector2(-0.18,0.42), Vector2(-0.22,0.08), Vector2(-0.12,-0.14)])
        "balloon":
            pts = PackedVector2Array([Vector2(0,-0.50), Vector2(0.32,-0.35), Vector2(0.46,-0.05), Vector2(0.35,0.25), Vector2(0.10,0.38), Vector2(0.06,0.50), Vector2(-0.06,0.50), Vector2(-0.10,0.38), Vector2(-0.35,0.25), Vector2(-0.46,-0.05), Vector2(-0.32,-0.35)])
        "kite":
            pts = PackedVector2Array([Vector2(0,-0.52), Vector2(0.40,0), Vector2(0,0.42), Vector2(-0.40,0)])
        "robot", "alien":
            pts = PackedVector2Array([Vector2(-0.30,-0.48), Vector2(0.30,-0.48), Vector2(0.30,-0.28), Vector2(0.44,-0.20), Vector2(0.44,0.24), Vector2(0.28,0.24), Vector2(0.28,0.48), Vector2(-0.28,0.48), Vector2(-0.28,0.24), Vector2(-0.44,0.24), Vector2(-0.44,-0.20), Vector2(-0.30,-0.28)])
        "guitar":
            pts = PackedVector2Array([Vector2(-0.42,0.18), Vector2(-0.25,-0.20), Vector2(0.02,-0.28), Vector2(0.16,-0.10), Vector2(0.46,-0.44), Vector2(0.50,-0.36), Vector2(0.20,0.02), Vector2(0.28,0.28), Vector2(0.05,0.46), Vector2(-0.25,0.38)])
        "note":
            pts = PackedVector2Array([Vector2(-0.28,-0.40), Vector2(0.28,-0.48), Vector2(0.28,0.24), Vector2(0.10,0.42), Vector2(-0.08,0.42), Vector2(-0.20,0.26), Vector2(-0.20,0.14), Vector2(0.10,0.14), Vector2(0.10,-0.26), Vector2(-0.28,-0.20)])
        "drum":
            pts = PackedVector2Array([Vector2(-0.44,-0.30), Vector2(0.44,-0.30), Vector2(0.36,0.36), Vector2(-0.36,0.36)])
        "trophy":
            pts = PackedVector2Array([Vector2(-0.34,-0.42), Vector2(0.34,-0.42), Vector2(0.28,0.02), Vector2(0.10,0.18), Vector2(0.10,0.36), Vector2(0.32,0.36), Vector2(0.32,0.48), Vector2(-0.32,0.48), Vector2(-0.32,0.36), Vector2(-0.10,0.36), Vector2(-0.10,0.18), Vector2(-0.28,0.02)])
        "shoe":
            pts = PackedVector2Array([Vector2(-0.48,0.10), Vector2(-0.10,-0.34), Vector2(0.10,-0.28), Vector2(0.20,-0.05), Vector2(0.48,0.12), Vector2(0.42,0.30), Vector2(-0.40,0.30)])
        "wrench":
            pts = PackedVector2Array([Vector2(-0.48,-0.18), Vector2(-0.22,-0.06), Vector2(0.18,-0.46), Vector2(0.34,-0.34), Vector2(0.22,-0.18), Vector2(0.48,0.10), Vector2(0.34,0.24), Vector2(0.18,0.14), Vector2(-0.10,0.42), Vector2(-0.26,0.26), Vector2(-0.14,0.10)])
        "hammer":
            pts = PackedVector2Array([Vector2(-0.44,-0.42), Vector2(0.12,-0.42), Vector2(0.12,-0.18), Vector2(0.28,-0.18), Vector2(0.28,0.48), Vector2(0.06,0.48), Vector2(0.06,-0.18), Vector2(-0.44,-0.18)])
        "gear":
            for i in range(24):
                var a = TAU * float(i) / 24.0
                var r = 0.50 if i % 2 == 0 else 0.38
                pts.append(Vector2(cos(a), sin(a)) * r)
        "car", "sportcar", "van":
            pts = PackedVector2Array([Vector2(-0.50,0.18), Vector2(-0.42,-0.08), Vector2(-0.18,-0.08), Vector2(-0.05,-0.30), Vector2(0.27,-0.30), Vector2(0.42,-0.08), Vector2(0.50,-0.02), Vector2(0.46,0.26), Vector2(0.28,0.26), Vector2(0.18,0.12), Vector2(-0.25,0.12), Vector2(-0.34,0.26), Vector2(-0.48,0.26)])
        "pickup":
            pts = PackedVector2Array([Vector2(-0.50,0.22), Vector2(-0.44,-0.10), Vector2(-0.05,-0.10), Vector2(0.04,-0.30), Vector2(0.30,-0.30), Vector2(0.42,-0.08), Vector2(0.50,-0.02), Vector2(0.46,0.26), Vector2(-0.48,0.26)])
        "truck", "tanker":
            pts = PackedVector2Array([Vector2(-0.50,-0.26), Vector2(0.10,-0.26), Vector2(0.10,-0.10), Vector2(0.36,-0.10), Vector2(0.50,0.05), Vector2(0.50,0.28), Vector2(-0.50,0.28)])
        "bus":
            pts = PackedVector2Array([Vector2(-0.50,-0.30), Vector2(0.50,-0.30), Vector2(0.50,0.30), Vector2(-0.50,0.30)])
        "bulldozer":
            pts = PackedVector2Array([Vector2(-0.48,0.20), Vector2(-0.36,-0.16), Vector2(0.12,-0.16), Vector2(0.18,-0.36), Vector2(0.36,-0.36), Vector2(0.42,-0.04), Vector2(0.50,0.10), Vector2(0.40,0.28), Vector2(-0.40,0.28)])
        "crane":
            pts = PackedVector2Array([Vector2(-0.44,0.40), Vector2(-0.28,0.40), Vector2(-0.28,-0.34), Vector2(0.42,-0.34), Vector2(0.42,-0.24), Vector2(-0.10,-0.16), Vector2(-0.10,0.40)])
        "plane":
            pts = PackedVector2Array([Vector2(-0.50,0.04), Vector2(-0.08,-0.08), Vector2(-0.02,-0.44), Vector2(0.10,-0.44), Vector2(0.14,-0.08), Vector2(0.50,0.04), Vector2(0.50,0.14), Vector2(0.12,0.10), Vector2(0.06,0.42), Vector2(-0.06,0.42), Vector2(-0.10,0.10), Vector2(-0.50,0.14)])
        "helicopter":
            pts = PackedVector2Array([Vector2(-0.46,-0.10), Vector2(0.10,-0.10), Vector2(0.22,-0.28), Vector2(0.36,-0.28), Vector2(0.42,-0.10), Vector2(0.50,-0.06), Vector2(0.46,0.02), Vector2(0.12,0.02), Vector2(0.10,0.28), Vector2(-0.20,0.28), Vector2(-0.28,0.10), Vector2(-0.46,0.10)])
        "rocket":
            pts = PackedVector2Array([Vector2(0,-0.52), Vector2(0.22,-0.24), Vector2(0.22,0.18), Vector2(0.42,0.42), Vector2(0.14,0.34), Vector2(0,0.50), Vector2(-0.14,0.34), Vector2(-0.42,0.42), Vector2(-0.22,0.18), Vector2(-0.22,-0.24)])
        "boat", "ship":
            pts = PackedVector2Array([Vector2(-0.50,0.08), Vector2(-0.38,0.34), Vector2(0.36,0.34), Vector2(0.50,0.08), Vector2(0.22,0.08), Vector2(0.22,-0.20), Vector2(-0.10,-0.20), Vector2(-0.10,-0.42), Vector2(-0.24,-0.42), Vector2(-0.24,0.08)])
        "submarine":
            pts = PackedVector2Array([Vector2(-0.50,-0.06), Vector2(-0.34,-0.28), Vector2(0.24,-0.28), Vector2(0.42,-0.10), Vector2(0.50,0), Vector2(0.42,0.10), Vector2(0.24,0.28), Vector2(-0.34,0.28), Vector2(-0.50,0.06)])
        "train", "metro", "tram":
            pts = PackedVector2Array([Vector2(-0.46,-0.42), Vector2(0.46,-0.42), Vector2(0.46,0.28), Vector2(0.28,0.48), Vector2(-0.28,0.48), Vector2(-0.46,0.28)])
        "bike", "motorcycle", "scooter":
            pts = PackedVector2Array([Vector2(-0.48,0.22), Vector2(-0.28,-0.06), Vector2(-0.04,0.18), Vector2(0.18,-0.18), Vector2(0.48,0.22), Vector2(0.36,0.36), Vector2(0.10,0.12), Vector2(-0.12,0.36), Vector2(-0.36,0.36)])
        "conveyor":
            pts = PackedVector2Array([Vector2(-0.50,-0.18), Vector2(0.50,-0.18), Vector2(0.50,0.18), Vector2(-0.50,0.18)])
        "traffic_sign":
            pts = PackedVector2Array([Vector2(0,-0.50), Vector2(0.42,-0.08), Vector2(0,0.34), Vector2(-0.42,-0.08)])
        "house", "villa":
            pts = PackedVector2Array([Vector2(-0.48,0.44), Vector2(-0.48,-0.06), Vector2(0,-0.48), Vector2(0.48,-0.06), Vector2(0.48,0.44)])
        "door":
            pts = PackedVector2Array([Vector2(-0.30,-0.50), Vector2(0.30,-0.50), Vector2(0.30,0.50), Vector2(-0.30,0.50)])
        "cat", "fox", "lion", "bear", "monkey":
            pts = PackedVector2Array([Vector2(-0.46,0.28), Vector2(-0.38,-0.14), Vector2(-0.22,-0.28), Vector2(-0.12,-0.46), Vector2(0,-0.32), Vector2(0.12,-0.46), Vector2(0.22,-0.28), Vector2(0.42,-0.14), Vector2(0.48,0.18), Vector2(0.28,0.38), Vector2(-0.18,0.42)])
        "dog":
            pts = PackedVector2Array([Vector2(-0.48,0.16), Vector2(-0.40,-0.24), Vector2(-0.20,-0.36), Vector2(0.08,-0.34), Vector2(0.22,-0.18), Vector2(0.42,-0.12), Vector2(0.48,0.18), Vector2(0.28,0.38), Vector2(-0.28,0.38)])
        "rabbit":
            pts = PackedVector2Array([Vector2(-0.34,0.30), Vector2(-0.30,-0.10), Vector2(-0.18,-0.48), Vector2(-0.02,-0.16), Vector2(0.10,-0.50), Vector2(0.20,-0.12), Vector2(0.38,0.04), Vector2(0.42,0.32), Vector2(0.18,0.46), Vector2(-0.18,0.44)])
        "bird", "owl", "eagle", "peacock", "chicken", "pterosaur":
            pts = PackedVector2Array([Vector2(-0.50,0.10), Vector2(-0.18,-0.10), Vector2(-0.08,-0.38), Vector2(0.10,-0.12), Vector2(0.48,0.02), Vector2(0.18,0.18), Vector2(0.02,0.42), Vector2(-0.16,0.18)])
        "horse", "cow", "sheep", "camel":
            pts = PackedVector2Array([Vector2(-0.48,0.20), Vector2(-0.42,-0.18), Vector2(0.12,-0.18), Vector2(0.22,-0.42), Vector2(0.40,-0.34), Vector2(0.48,-0.08), Vector2(0.36,0.16), Vector2(0.24,0.22), Vector2(0.20,0.46), Vector2(0.04,0.46), Vector2(0.00,0.20), Vector2(-0.26,0.22), Vector2(-0.28,0.46), Vector2(-0.42,0.46)])
        "elephant":
            pts = PackedVector2Array([Vector2(-0.48,0.28), Vector2(-0.42,-0.12), Vector2(-0.18,-0.32), Vector2(0.18,-0.32), Vector2(0.36,-0.18), Vector2(0.46,0.02), Vector2(0.48,0.40), Vector2(0.34,0.44), Vector2(0.24,0.08), Vector2(0.12,0.22), Vector2(-0.16,0.22), Vector2(-0.20,0.48), Vector2(-0.36,0.48), Vector2(-0.36,0.24)])
        "giraffe":
            pts = PackedVector2Array([Vector2(-0.42,0.42), Vector2(-0.42,0.04), Vector2(-0.18,-0.10), Vector2(0.12,-0.10), Vector2(0.16,-0.42), Vector2(0.28,-0.50), Vector2(0.42,-0.42), Vector2(0.34,-0.22), Vector2(0.28,0.18), Vector2(0.14,0.18), Vector2(0.10,0.46), Vector2(-0.06,0.46), Vector2(-0.10,0.18), Vector2(-0.28,0.18), Vector2(-0.28,0.42)])
        "snake":
            pts = PackedVector2Array([Vector2(-0.48,-0.26), Vector2(-0.10,-0.26), Vector2(-0.10,-0.06), Vector2(0.28,-0.06), Vector2(0.28,0.12), Vector2(-0.18,0.12), Vector2(-0.18,0.30), Vector2(0.48,0.30), Vector2(0.48,0.46), Vector2(-0.34,0.46), Vector2(-0.34,0.08), Vector2(0.10,0.08), Vector2(0.10,-0.10), Vector2(-0.48,-0.10)])
        "scorpion":
            pts = PackedVector2Array([Vector2(-0.46,0.10), Vector2(-0.22,-0.20), Vector2(0.10,-0.26), Vector2(0.24,-0.10), Vector2(0.42,-0.28), Vector2(0.50,-0.12), Vector2(0.34,0.02), Vector2(0.46,0.24), Vector2(0.22,0.18), Vector2(0.08,0.42), Vector2(-0.10,0.22), Vector2(-0.34,0.32)])
        "fish", "dolphin":
            pts = PackedVector2Array([Vector2(-0.50,0), Vector2(-0.28,-0.24), Vector2(0.18,-0.30), Vector2(0.44,-0.12), Vector2(0.50,0), Vector2(0.44,0.12), Vector2(0.18,0.30), Vector2(-0.28,0.24)])
        "turtle":
            pts = PackedVector2Array([Vector2(-0.50,0), Vector2(-0.32,-0.12), Vector2(-0.20,-0.34), Vector2(0.20,-0.34), Vector2(0.34,-0.12), Vector2(0.50,0), Vector2(0.34,0.12), Vector2(0.20,0.34), Vector2(-0.20,0.34), Vector2(-0.32,0.12)])
        "octopus":
            pts = PackedVector2Array([Vector2(-0.34,-0.20), Vector2(-0.20,-0.44), Vector2(0.20,-0.44), Vector2(0.34,-0.20), Vector2(0.38,0.10), Vector2(0.50,0.34), Vector2(0.30,0.26), Vector2(0.18,0.48), Vector2(0.04,0.26), Vector2(-0.08,0.48), Vector2(-0.22,0.26), Vector2(-0.40,0.40), Vector2(-0.36,0.08)])
        "butterfly", "dragonfly":
            pts = PackedVector2Array([Vector2(0,-0.10), Vector2(-0.18,-0.42), Vector2(-0.48,-0.30), Vector2(-0.28,0.02), Vector2(-0.46,0.34), Vector2(-0.14,0.42), Vector2(0,0.12), Vector2(0.14,0.42), Vector2(0.46,0.34), Vector2(0.28,0.02), Vector2(0.48,-0.30), Vector2(0.18,-0.42)])
        "bee", "beetle":
            pts = PackedVector2Array([Vector2(-0.44,0), Vector2(-0.24,-0.30), Vector2(0.24,-0.30), Vector2(0.44,0), Vector2(0.24,0.30), Vector2(-0.24,0.30)])
        "crocodile", "lizard":
            pts = PackedVector2Array([Vector2(-0.50,-0.10), Vector2(0.20,-0.18), Vector2(0.46,-0.06), Vector2(0.50,0.08), Vector2(0.20,0.18), Vector2(-0.50,0.10)])
        "dinosaur", "trex":
            pts = PackedVector2Array([Vector2(-0.48,0.30), Vector2(-0.36,-0.10), Vector2(-0.14,-0.20), Vector2(0.02,-0.44), Vector2(0.30,-0.42), Vector2(0.48,-0.20), Vector2(0.34,0.02), Vector2(0.18,0.06), Vector2(0.16,0.44), Vector2(-0.02,0.44), Vector2(-0.08,0.16), Vector2(-0.30,0.18)])
        "egg":
            for i in range(40):
                var a = TAU * float(i) / 40.0
                var y_scale = 0.56 if sin(a) < 0 else 0.46
                pts.append(Vector2(cos(a) * 0.38, sin(a) * y_scale))
        "apple", "pear":
            pts = PackedVector2Array([Vector2(0,-0.46), Vector2(0.14,-0.34), Vector2(0.36,-0.26), Vector2(0.48,0.02), Vector2(0.34,0.36), Vector2(0,0.48), Vector2(-0.34,0.36), Vector2(-0.48,0.02), Vector2(-0.36,-0.26), Vector2(-0.14,-0.34)])
        "banana":
            pts = PackedVector2Array([Vector2(-0.48,-0.16), Vector2(-0.28,-0.28), Vector2(0.02,-0.26), Vector2(0.34,-0.08), Vector2(0.48,0.16), Vector2(0.34,0.28), Vector2(0.06,0.12), Vector2(-0.20,0.06), Vector2(-0.40,0.14)])
        "grapes":
            return _shape_local_polygon("flower")
        "carrot":
            pts = PackedVector2Array([Vector2(-0.24,-0.44), Vector2(0.24,-0.44), Vector2(0.12,-0.22), Vector2(0.38,-0.08), Vector2(0.14,-0.02), Vector2(0,0.50), Vector2(-0.14,-0.02), Vector2(-0.38,-0.08), Vector2(-0.12,-0.22)])
        "pepper", "eggplant":
            return _shape_local_polygon("apple")
        "corn":
            pts = PackedVector2Array([Vector2(-0.16,-0.48), Vector2(0.16,-0.48), Vector2(0.28,-0.16), Vector2(0.22,0.34), Vector2(0,0.50), Vector2(-0.22,0.34), Vector2(-0.28,-0.16)])
        "cake":
            pts = PackedVector2Array([Vector2(-0.46,-0.24), Vector2(0.46,-0.24), Vector2(0.46,0.38), Vector2(-0.46,0.38), Vector2(-0.40,-0.06), Vector2(-0.20,-0.14), Vector2(0,-0.06), Vector2(0.20,-0.14), Vector2(0.40,-0.06)])
        "icecream":
            pts = PackedVector2Array([Vector2(-0.28,-0.36), Vector2(0.28,-0.36), Vector2(0.38,-0.10), Vector2(0.20,0.02), Vector2(0,0.50), Vector2(-0.20,0.02), Vector2(-0.38,-0.10)])
        "candy":
            pts = PackedVector2Array([Vector2(-0.48,-0.18), Vector2(-0.28,-0.30), Vector2(-0.16,-0.18), Vector2(0.16,-0.18), Vector2(0.28,-0.30), Vector2(0.48,-0.18), Vector2(0.30,0), Vector2(0.48,0.18), Vector2(0.28,0.30), Vector2(0.16,0.18), Vector2(-0.16,0.18), Vector2(-0.28,0.30), Vector2(-0.48,0.18), Vector2(-0.30,0)])
        "teapot":
            pts = PackedVector2Array([Vector2(-0.40,-0.24), Vector2(0.22,-0.24), Vector2(0.36,-0.08), Vector2(0.50,0), Vector2(0.34,0.10), Vector2(0.24,0.34), Vector2(-0.26,0.34), Vector2(-0.38,0.10), Vector2(-0.50,0.04), Vector2(-0.50,-0.06)])
        "pizza":
            pts = PackedVector2Array([Vector2(0,-0.50), Vector2(0.48,0.38), Vector2(-0.48,0.38)])
        "burger":
            pts = PackedVector2Array([Vector2(-0.46,-0.12), Vector2(-0.34,-0.34), Vector2(0.34,-0.34), Vector2(0.46,-0.12), Vector2(0.42,0.10), Vector2(0.48,0.30), Vector2(-0.48,0.30), Vector2(-0.42,0.10)])
        "sandwich":
            pts = PackedVector2Array([Vector2(0,-0.48), Vector2(0.50,0.34), Vector2(-0.50,0.34)])
        "fries":
            pts = PackedVector2Array([Vector2(-0.38,-0.28), Vector2(-0.30,-0.46), Vector2(-0.16,-0.28), Vector2(-0.06,-0.50), Vector2(0.08,-0.28), Vector2(0.18,-0.46), Vector2(0.30,-0.26), Vector2(0.38,0.42), Vector2(-0.38,0.42)])
        "tree", "pine":
            pts = PackedVector2Array([Vector2(0,-0.50), Vector2(0.34,-0.12), Vector2(0.18,-0.12), Vector2(0.46,0.18), Vector2(0.14,0.18), Vector2(0.14,0.48), Vector2(-0.14,0.48), Vector2(-0.14,0.18), Vector2(-0.46,0.18), Vector2(-0.18,-0.12), Vector2(-0.34,-0.12)])
        "palm":
            pts = PackedVector2Array([Vector2(-0.08,0.48), Vector2(0.08,0.48), Vector2(0.12,-0.12), Vector2(0.46,-0.18), Vector2(0.20,-0.34), Vector2(0.04,-0.18), Vector2(-0.16,-0.46), Vector2(-0.12,-0.14), Vector2(-0.46,-0.18), Vector2(-0.20,-0.02), Vector2(0,-0.06)])
        "leaf":
            pts = PackedVector2Array([Vector2(-0.46,0.10), Vector2(-0.18,-0.30), Vector2(0.20,-0.44), Vector2(0.48,-0.10), Vector2(0.18,0.30), Vector2(-0.20,0.44)])
        "cactus":
            pts = PackedVector2Array([Vector2(-0.12,-0.48), Vector2(0.12,-0.48), Vector2(0.12,-0.12), Vector2(0.26,-0.22), Vector2(0.38,-0.16), Vector2(0.34,0.02), Vector2(0.12,0.10), Vector2(0.12,0.48), Vector2(-0.12,0.48), Vector2(-0.12,0.12), Vector2(-0.34,0.02), Vector2(-0.38,-0.16), Vector2(-0.26,-0.22), Vector2(-0.12,-0.12)])
        "pot":
            pts = PackedVector2Array([Vector2(-0.34,-0.20), Vector2(0.34,-0.20), Vector2(0.26,0.42), Vector2(-0.26,0.42)])
        "bench":
            pts = PackedVector2Array([Vector2(-0.48,-0.22), Vector2(0.48,-0.22), Vector2(0.48,0.02), Vector2(0.38,0.02), Vector2(0.38,0.44), Vector2(0.24,0.44), Vector2(0.24,0.02), Vector2(-0.24,0.02), Vector2(-0.24,0.44), Vector2(-0.38,0.44), Vector2(-0.38,0.02), Vector2(-0.48,0.02)])
        "tower", "skyscraper", "lighthouse":
            pts = PackedVector2Array([Vector2(-0.26,-0.50), Vector2(0.26,-0.50), Vector2(0.34,0.46), Vector2(-0.34,0.46)])
        "castle":
            pts = PackedVector2Array([Vector2(-0.48,-0.34), Vector2(-0.32,-0.34), Vector2(-0.32,-0.50), Vector2(-0.14,-0.50), Vector2(-0.14,-0.32), Vector2(0.14,-0.32), Vector2(0.14,-0.50), Vector2(0.32,-0.50), Vector2(0.32,-0.34), Vector2(0.48,-0.34), Vector2(0.48,0.46), Vector2(-0.48,0.46)])
        "bridge":
            pts = PackedVector2Array([Vector2(-0.50,0.22), Vector2(-0.38,-0.10), Vector2(-0.18,-0.22), Vector2(0,-0.28), Vector2(0.18,-0.22), Vector2(0.38,-0.10), Vector2(0.50,0.22), Vector2(0.50,0.38), Vector2(-0.50,0.38)])
        "factory":
            pts = PackedVector2Array([Vector2(-0.48,0.46), Vector2(-0.48,-0.04), Vector2(-0.26,-0.04), Vector2(-0.26,-0.34), Vector2(-0.08,-0.34), Vector2(-0.08,-0.04), Vector2(0.12,-0.20), Vector2(0.28,-0.04), Vector2(0.48,-0.20), Vector2(0.48,0.46)])
        "phone":
            pts = PackedVector2Array([Vector2(-0.28,-0.50), Vector2(0.28,-0.50), Vector2(0.34,-0.42), Vector2(0.34,0.42), Vector2(0.28,0.50), Vector2(-0.28,0.50), Vector2(-0.34,0.42), Vector2(-0.34,-0.42)])
        "laptop":
            pts = PackedVector2Array([Vector2(-0.42,-0.42), Vector2(0.42,-0.42), Vector2(0.36,0.14), Vector2(0.50,0.38), Vector2(-0.50,0.38), Vector2(-0.36,0.14)])
        "moon":
            pts = PackedVector2Array([Vector2(-0.10,-0.50), Vector2(0.22,-0.38), Vector2(0.42,-0.14), Vector2(0.46,0.16), Vector2(0.28,0.40), Vector2(-0.06,0.50), Vector2(-0.30,0.36), Vector2(-0.12,0.20), Vector2(0.02,0.02), Vector2(0.02,-0.18), Vector2(-0.10,-0.50)])
        "dragon":
            pts = PackedVector2Array([Vector2(-0.48,0.30), Vector2(-0.34,-0.06), Vector2(-0.18,-0.28), Vector2(0.02,-0.18), Vector2(0.14,-0.48), Vector2(0.28,-0.22), Vector2(0.46,-0.10), Vector2(0.30,0.06), Vector2(0.48,0.30), Vector2(0.14,0.24), Vector2(0.02,0.48), Vector2(-0.12,0.24), Vector2(-0.34,0.42)])
        _:
            pts = PackedVector2Array([Vector2(-0.50,-0.40), Vector2(0.50,-0.40), Vector2(0.50,0.40), Vector2(-0.50,0.40)])
    return pts

func _inside_board(cell):
    return cell.x >= 0 and cell.y >= 0 and cell.x < grid_w and cell.y < grid_h

func _ray_clear_board(head, direction):
    var probe = head + direction
    while _inside_board(probe):
        if occupancy.has(probe):
            return false
        probe += direction
    return true

func _generate_routes(profile, rng):
    var result = []
    var target = int(profile["routes"])
    var attempts = 0
    var max_attempts = max(12000, target * 220)

    while result.size() < target and attempts < max_attempts:
        attempts += 1
        if valid_cells.is_empty():
            break
        var span = max(0, int(profile["max_len"]) - int(profile["min_len"]))
        var length_bias = 1.45 + float(_local_level(stage)) * 0.025 + float(_world_number(stage) - 1) * 0.010
        if stage > BASE_LEVELS:
            var advanced_world_index = _world_number(stage) - BASE_WORLDS
            var world_t = float(max(0, advanced_world_index - 1)) / float(max(1, ADVANCED_WORLDS - 1))
            var local_t = float(_local_level(stage) - 1) / 19.0
            length_bias = clamp(1.18 - world_t * 0.28 - local_t * 0.38, 0.55, 1.18)
        var biased = pow(rng.randf(), length_bias)
        var desired = int(profile["min_len"]) + int(round(biased * float(span)))
        var candidate = _try_generate_route(desired, float(profile["turn_chance"]), int(profile["max_turns"]), rng)
        if candidate.is_empty():
            continue
        var index = result.size()
        for cell in candidate["cells"]:
            occupancy[cell] = index
        result.append(candidate)

    occupancy.clear()
    return result

func _try_generate_route(desired_len, turn_chance, max_turns, rng):
    var dirs = [Vector2i(1,0), Vector2i(-1,0), Vector2i(0,1), Vector2i(0,-1)]
    for outer in range(65):
        var head = valid_cells[rng.randi_range(0, valid_cells.size() - 1)]
        if occupancy.has(head) or not region_map.has(head):
            continue
        var region = int(region_map[head])
        var exit_dir = dirs[rng.randi_range(0, dirs.size()-1)]
        var first_tail = head - exit_dir
        if not _same_region(first_tail, region) or occupancy.has(first_tail):
            continue
        # A formation only controls where the arrow is built. Once fired,
        # every arrow belongs to one shared arena. Therefore its exit lane is
        # checked through the whole board, not merely inside its formation.
        if not _ray_clear_board(head, exit_dir):
            continue

        var exit_lane = {}
        var exit_probe = head + exit_dir
        while _same_region(exit_probe, region):
            exit_lane[exit_probe] = true
            exit_probe += exit_dir

        var reverse_cells = [head, first_tail]
        var local_used = {head:true, first_tail:true}
        var current = first_tail
        var back_dir = -exit_dir
        var turns = 0

        while reverse_cells.size() < desired_len:
            var straight = []
            var turning = []
            for d in dirs:
                if d == -back_dir:
                    continue
                var next = current + d
                if not _same_region(next, region) or occupancy.has(next) or local_used.has(next) or exit_lane.has(next):
                    continue
                if d == back_dir:
                    straight.append(d)
                elif turns < max_turns:
                    turning.append(d)

            if straight.is_empty() and turning.is_empty():
                break

            var chosen = back_dir
            var make_turn = false
            if not turning.is_empty() and (straight.is_empty() or rng.randf() < turn_chance):
                chosen = turning[rng.randi_range(0, turning.size()-1)]
                make_turn = true
            else:
                chosen = straight[rng.randi_range(0, straight.size()-1)] if not straight.is_empty() else turning[rng.randi_range(0, turning.size()-1)]
                make_turn = chosen != back_dir
            if make_turn:
                turns += 1
            current += chosen
            reverse_cells.append(current)
            local_used[current] = true
            back_dir = chosen

        if reverse_cells.size() < 2:
            continue
        reverse_cells.reverse()
        return {"cells": reverse_cells, "exit": exit_dir, "region": region}
    return {}

func _same_region(cell, region):
    return region_map.has(cell) and int(region_map[cell]) == region

func _ray_clear_region(head, direction, region):
    var probe = head + direction
    while _same_region(probe, region):
        if occupancy.has(probe):
            return false
        probe += direction
    return true

func _blocking_steps(route):
    if not route_cells.has(route):
        return -1
    var cells = route_cells[route]
    if cells.is_empty():
        return -1
    var head = cells[cells.size()-1]
    var direction = Vector2i(int(round(route.exit_dir.x)), int(round(route.exit_dir.y)))
    var probe = head + direction
    var steps = 1

    # GLOBAL ARENA: ignore formation boundaries. An arrow fired from the bottom
    # may cross a circle, triangle, car, animal, etc. It is stopped only by an
    # actual arrow occupying its lane.
    while _inside_board(probe):
        if occupancy.has(probe) and occupancy[probe] != route:
            return steps
        probe += direction
        steps += 1
    return -1

func _select_route(route):
    if stage_transition or not is_instance_valid(route) or route.busy:
        return
    var block_steps = _blocking_steps(route)
    if block_steps < 0:
        var exit_distance = _distance_from_head_to_board_edge(route)
        var cells = route_cells.get(route, [])
        for cell in cells:
            if occupancy.get(cell, null) == route:
                occupancy.erase(cell)
        route_cells.erase(route)
        route_region.erase(route)
        remaining -= 1
        route.animate_escape(route.total_length + exit_distance)
        _update_ui()
        if remaining <= 0:
            _complete_stage()
    else:
        var distance = max(cell_size * 0.28, (float(block_steps) - 0.52) * cell_size)
        route.animate_block(distance)
        _consume_error()

func _distance_from_head_to_board_edge(route):
    if not route_cells.has(route):
        return route.head_length + max(28.0, cell_size * 0.8)
    var cells = route_cells[route]
    if cells.is_empty():
        return route.head_length + max(28.0, cell_size * 0.8)
    var head = cells[cells.size() - 1]
    var dir = Vector2i(int(round(route.exit_dir.x)), int(round(route.exit_dir.y)))
    var probe = head + dir
    var steps = 0
    while _inside_board(probe):
        steps += 1
        probe += dir

    # Keep moving until the complete tail clears the shared arena.
    return float(steps + 1) * cell_size + route.head_length + max(34.0, cell_size * 0.95)

func _on_route_escape_finished(route):
    routes.erase(route)

func _show_hint():
    if stage_transition or game_over:
        return
    for route in routes:
        if is_instance_valid(route) and not route.busy and _blocking_steps(route) < 0:
            route.flash_hint()
            return

func _pick_route(screen_point):
    if stage_transition or game_over:
        return
    var best = null
    var best_distance = INF
    var radius = clamp(cell_size * 0.72, 17.0, 34.0)
    if camera_2d != null:
        radius = max(radius, 26.0 / max(0.18, camera_2d.zoom.x))
    for route in routes:
        if not is_instance_valid(route) or route.busy:
            continue
        var d = route.distance_to_route(screen_point)
        if d < radius and d < best_distance:
            best = route
            best_distance = d
    if best != null:
        _select_route(best)

func _unhandled_input(event):
    if event is InputEventMouseButton:
        if event.button_index == MOUSE_BUTTON_WHEEL_UP and event.pressed:
            _apply_zoom(1.10)
            return
        elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN and event.pressed:
            _apply_zoom(0.90)
            return
        elif event.button_index == MOUSE_BUTTON_LEFT:
            if event.pressed:
                press_start = event.position
                press_travel = 0.0
                single_pan_active = false
            else:
                if not single_pan_active and press_travel < 14.0 and not game_over and not stage_transition:
                    _pick_route(_screen_to_world(event.position))
                single_pan_active = false
    elif event is InputEventMouseMotion and (event.button_mask & MOUSE_BUTTON_MASK_LEFT) != 0:
        press_travel += event.relative.length()
        if press_travel > 9.0:
            single_pan_active = true
            _pan_view(event.relative)
    elif event is InputEventMouseMotion and (event.button_mask & MOUSE_BUTTON_MASK_MIDDLE) != 0:
        _pan_view(event.relative)
    elif event is InputEventScreenTouch:
        if event.pressed:
            touches[event.index] = event.position
            if touches.size() >= 2:
                gesture_had_multitouch = true
                var pts = touches.values()
                pinch_last_distance = pts[0].distance_to(pts[1])
                pinch_last_center = (pts[0] + pts[1]) * 0.5
            else:
                press_start = event.position
                press_travel = 0.0
                single_pan_active = false
                gesture_had_multitouch = false
        else:
            var was_single = touches.size() == 1 and touches.has(event.index)
            if was_single and not gesture_had_multitouch and not single_pan_active and press_travel < 14.0 and not game_over and not stage_transition:
                _pick_route(_screen_to_world(event.position))
            touches.erase(event.index)
            if touches.is_empty():
                pinch_last_distance = -1.0
                single_pan_active = false
                gesture_had_multitouch = false
            elif touches.size() < 2:
                pinch_last_distance = -1.0
    elif event is InputEventScreenDrag:
        touches[event.index] = event.position
        if touches.size() >= 2 and camera_2d != null:
            gesture_had_multitouch = true
            var pts = touches.values()
            var current_distance = pts[0].distance_to(pts[1])
            var current_center = (pts[0] + pts[1]) * 0.5
            if pinch_last_distance > 0.0 and current_distance > 0.0:
                _apply_zoom(current_distance / pinch_last_distance)
                _pan_view(current_center - pinch_last_center)
            pinch_last_distance = current_distance
            pinch_last_center = current_center
        else:
            press_travel += event.relative.length()
            if press_travel > 9.0:
                single_pan_active = true
                _pan_view(event.relative)

func _update_ui():
    var world = _world_number(stage)
    var local_level = _local_level(stage)
    var phase_name = "المرحلة الأساسية" if stage <= BASE_LEVELS else "المرحلة المتقدمة"
    world_label.text = "%s • العالم %d/%d • %s" % [phase_name, world, TOTAL_WORLDS, WorldData.world_name(world)]
    stage_label.text = "المستوى %d/20 • التقدم %d/%d" % [local_level, stage, TOTAL_LEVELS]
    progress_label.text = "المتبقي: %d مسار • الأخطاء المتبقية: %d" % [remaining, lives_left]
    var profile = _stage_profile(stage)
    density_label.text = "%s • %d تشكيلات • شبكة %d×%d • ساحة ×%.1f • اسحب الشاشة بعد التكبير" % [_difficulty_name(stage), shape_specs.size(), profile["w"], profile["h"], profile["arena_scale"]]

func _complete_stage():
    if stage_transition:
        return
    stage_transition = true
    var world = _world_number(stage)
    var local_level = _local_level(stage)
    if stage >= TOTAL_LEVELS:
        message_label.text = "ممتاز! أكملت 11000 مستوى ✓"
        message_label.visible = true
        _save_stage(TOTAL_LEVELS)
        return

    if stage == BASE_LEVELS:
        message_label.text = "أكملت المرحلة الأساسية ✓\nتم فتح المرحلة المتقدمة: 10000 مستوى جديد"
    elif local_level == 20:
        message_label.text = "اكتمل عالم %s ✓\nالعالم التالي: %s" % [WorldData.world_name(world), WorldData.world_name(world + 1)]
    else:
        message_label.text = "أحسنت! اكتمل المستوى %d" % local_level
    message_label.visible = true
    _save_stage(stage + 1)
    var timer = get_tree().create_timer(1.05)
    timer.timeout.connect(func(): _load_stage(stage + 1))

func _load_saved_stage():
    var config = ConfigFile.new()
    if config.load("user://arrow_escape_v19_11000.cfg") == OK:
        return clamp(int(config.get_value("progress", "stage", 1)), 1, TOTAL_LEVELS)
    var old_config = ConfigFile.new()
    if old_config.load("user://arrow_escape_v18_1000.cfg") == OK:
        return clamp(int(old_config.get_value("progress", "stage", 1)), 1, TOTAL_LEVELS)
    return 1

func _save_stage(value):
    var config = ConfigFile.new()
    config.set_value("progress", "stage", clamp(int(value), 1, TOTAL_LEVELS))
    config.save("user://arrow_escape_v19_11000.cfg")
